Clazz.declarePackage ("JSV.dialog");
c$ = Clazz.declareType (JSV.dialog, "DialogParams");
