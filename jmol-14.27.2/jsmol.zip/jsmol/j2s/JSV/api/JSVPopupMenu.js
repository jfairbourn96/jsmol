Clazz.declarePackage ("JSV.api");
Clazz.load (["javajs.api.GenericMenuInterface"], "JSV.api.JSVPopupMenu", null, function () {
Clazz.declareInterface (JSV.api, "JSVPopupMenu", javajs.api.GenericMenuInterface);
});
