Clazz.declarePackage ("J.adapter.readers.qcschema");
c$ = Clazz.declareType (J.adapter.readers.qcschema, "QCSchemaReader");
